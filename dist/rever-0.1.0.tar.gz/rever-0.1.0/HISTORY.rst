-------
History
-------

version 0.1.0 (6/24/2017)
-------------------------

- specify whether or not to raise exception after all retry attemtps
- included some testing
- default pause is now zero seconds

version 0.0.1 (6/23/2017)
-------------------------

- retry decorator
- specify number of times to retry
- specify number of seconds to wait
- specify which exceptions to catch